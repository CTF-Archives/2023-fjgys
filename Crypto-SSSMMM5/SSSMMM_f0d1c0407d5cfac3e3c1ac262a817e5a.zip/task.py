from Crypto.Util.number import long_to_bytes, bytes_to_long, inverse
from Crypto.Util.Padding import pad
from Crypto.Cipher import AES
from random import getrandbits
from secret import flag
import hashlib
import base64

flag = pad(flag, 16)

ecc_table = {
    'n': 'FFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFF7203DF6B21C6052B53BBF40939D54123',
    'p': 'FFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00000000FFFFFFFFFFFFFFFF',
    'g': '32c4ae2c1f1981195f9904466a39c9948fe30bbff2660be1715a4589334c74c7'
         'bc3736a2f4f6779c59bdcee36b692153d0a9877cc62a474002df32e52139f0a0',
    'a': 'FFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00000000FFFFFFFFFFFFFFFC',
    'b': '28E9FA9E9D9F5E344D5A9E4BCF6509A7F39789F515AB8F92DDBCBD414D940E93',
}

class TSM2(object):
    def __init__(self, sk, ecc_table):
        self.ecc_table = ecc_table
        self.n = int(ecc_table['n'], 16)
        self.para_len = len(ecc_table['n'])
        self.ecc_a3 = (int(ecc_table['a'], base=16) +
                       3) % int(ecc_table['p'], base=16)
 
        self.sk = sk
        self.pk = self._kg(self.sk, ecc_table['g'])
 
    def sign(self, data, K):
        e = data
        d = self.sk
        k = K
 
        P1 = self._kg(k, self.ecc_table['g'])
        x = int(P1[0:self.para_len], 16)
        R = ((e + x) % int(self.ecc_table['n'], base=16))
        if R == 0 or R + k == int(self.ecc_table['n'], base=16):
            return None
        d_1 = pow(
            d+1, int(self.ecc_table['n'], base=16) - 2, int(self.ecc_table['n'], base=16))
        S = (d_1*(k + R) - R) % int(self.ecc_table['n'], base=16)
        if S == 0:
            return None
        else:
            return '%064x%064x' % (R, S)
 
    def verify(self, Sign, data):
        r = int(Sign[0:self.para_len], 16)
        s = int(Sign[self.para_len:2 * self.para_len], 16)
        e = int(data.hex(), 16)
        t = (r + s) % self.n
        if t == 0:
            return 0
 
        P1 = self._kg(s, self.ecc_table['g'])
        P2 = self._kg(t, self.pk)
 
        if P1 == P2:
            P1 = '%s%s' % (P1, 1)
            P1 = self._double_point(P1)
        else:
            P1 = '%s%s' % (P1, 1)
            P1 = self._add_point(P1, P2)
            P1 = self._convert_jacb_to_nor(P1)
 
        x = int(P1[0:self.para_len], 16)
        return r == ((e + x) % self.n)
 
    def _kg(self, k, Point):
        if (k % self.n) == 0:
            return '0' * 128
        Point = '%s%s' % (Point, '1')
        mask_str = '8'
        for i in range(self.para_len - 1):
            mask_str += '0'
        mask = int(mask_str, 16)
        Temp = Point
        flag = False
        for n in range(self.para_len * 4):
            if flag:
                Temp = self._double_point(Temp)
            if (k & mask) != 0:
                if flag:
                    Temp = self._add_point(Temp, Point)
                else:
                    flag = True
                    Temp = Point
            k = k << 1
        return self._convert_jacb_to_nor(Temp)
 
    def _double_point(self, Point):
        l = len(Point)
        len_2 = 2 * self.para_len
        if l < self.para_len * 2:
            return None
        else:
            x1 = int(Point[0:self.para_len], 16)
            y1 = int(Point[self.para_len:len_2], 16)
            if l == len_2:
                z1 = 1
            else:
                z1 = int(Point[len_2:], 16)
 
            T6 = (z1 * z1) % int(self.ecc_table['p'], base=16)
            T2 = (y1 * y1) % int(self.ecc_table['p'], base=16)
            T3 = (x1 + T6) % int(self.ecc_table['p'], base=16)
            T4 = (x1 - T6) % int(self.ecc_table['p'], base=16)
            T1 = (T3 * T4) % int(self.ecc_table['p'], base=16)
            T3 = (y1 * z1) % int(self.ecc_table['p'], base=16)
            T4 = (T2 * 8) % int(self.ecc_table['p'], base=16)
            T5 = (x1 * T4) % int(self.ecc_table['p'], base=16)
            T1 = (T1 * 3) % int(self.ecc_table['p'], base=16)
            T6 = (T6 * T6) % int(self.ecc_table['p'], base=16)
            T6 = (self.ecc_a3 * T6) % int(self.ecc_table['p'], base=16)
            T1 = (T1 + T6) % int(self.ecc_table['p'], base=16)
            z3 = (T3 + T3) % int(self.ecc_table['p'], base=16)
            T3 = (T1 * T1) % int(self.ecc_table['p'], base=16)
            T2 = (T2 * T4) % int(self.ecc_table['p'], base=16)
            x3 = (T3 - T5) % int(self.ecc_table['p'], base=16)
 
            if (T5 % 2) == 1:
                T4 = (T5 + ((T5 + int(self.ecc_table['p'], base=16)) >> 1) - T3) % int(
                    self.ecc_table['p'], base=16)
            else:
                T4 = (T5 + (T5 >> 1) - T3) % int(self.ecc_table['p'], base=16)
 
            T1 = (T1 * T4) % int(self.ecc_table['p'], base=16)
            y3 = (T1 - T2) % int(self.ecc_table['p'], base=16)
 
            form = '%%0%dx' % self.para_len
            form = form * 3
            return form % (x3, y3, z3)
 
    def _add_point(self, P1, P2):
        if P1 == '0' * 128:
            return '%s%s' % (P2, '1')
        if P2 == '0' * 128:
            return '%s%s' % (P1, '1')
        len_2 = 2 * self.para_len
        l1 = len(P1)
        l2 = len(P2)
        if (l1 < len_2) or (l2 < len_2):
            return None
        else:
            X1 = int(P1[0:self.para_len], 16)
            Y1 = int(P1[self.para_len:len_2], 16)
            if l1 == len_2:
                Z1 = 1
            else:
                Z1 = int(P1[len_2:], 16)
            x2 = int(P2[0:self.para_len], 16)
            y2 = int(P2[self.para_len:len_2], 16)
 
            T1 = (Z1 * Z1) % int(self.ecc_table['p'], base=16)
            T2 = (y2 * Z1) % int(self.ecc_table['p'], base=16)
            T3 = (x2 * T1) % int(self.ecc_table['p'], base=16)
            T1 = (T1 * T2) % int(self.ecc_table['p'], base=16)
            T2 = (T3 - X1) % int(self.ecc_table['p'], base=16)
            T3 = (T3 + X1) % int(self.ecc_table['p'], base=16)
            T4 = (T2 * T2) % int(self.ecc_table['p'], base=16)
            T1 = (T1 - Y1) % int(self.ecc_table['p'], base=16)
            Z3 = (Z1 * T2) % int(self.ecc_table['p'], base=16)
            T2 = (T2 * T4) % int(self.ecc_table['p'], base=16)
            T3 = (T3 * T4) % int(self.ecc_table['p'], base=16)
            T5 = (T1 * T1) % int(self.ecc_table['p'], base=16)
            T4 = (X1 * T4) % int(self.ecc_table['p'], base=16)
            X3 = (T5 - T3) % int(self.ecc_table['p'], base=16)
            T2 = (Y1 * T2) % int(self.ecc_table['p'], base=16)
            T3 = (T4 - X3) % int(self.ecc_table['p'], base=16)
            T1 = (T1 * T3) % int(self.ecc_table['p'], base=16)
            Y3 = (T1 - T2) % int(self.ecc_table['p'], base=16)
 
            form = '%%0%dx' % self.para_len
            form = form * 3
            return form % (X3, Y3, Z3)
    
    def _convert_jacb_to_nor(self, Point):
        len_2 = 2 * self.para_len
        x = int(Point[0:self.para_len], 16)
        y = int(Point[self.para_len:len_2], 16)
        z = int(Point[len_2:], 16)
        z_inv = pow(
            z, int(self.ecc_table['p'], base=16) - 2, int(self.ecc_table['p'], base=16))
        z_invSquar = (z_inv * z_inv) % int(self.ecc_table['p'], base=16)
        z_invQube = (z_invSquar * z_inv) % int(self.ecc_table['p'], base=16)
        x_new = (x * z_invSquar) % int(self.ecc_table['p'], base=16)
        y_new = (y * z_invQube) % int(self.ecc_table['p'], base=16)
        z_new = (z * z_inv) % int(self.ecc_table['p'], base=16)
        if z_new == 1:
            form = '%%0%dx' % self.para_len
            form = form * 2
            return form % (x_new, y_new)
        else:
            return None

def leak(start, bits, k):
    return int(bin(k)[2:][-start-bits:-start],2)

sk = getrandbits(256) % int(ecc_table['n'], 16)
sm2 = TSM2(sk, ecc_table)
start = 130
bits = 7
num = 50

sigs = []
L = []
for i in range(num):
    msg = getrandbits(256) % int(ecc_table['n'], 16)
    k = getrandbits(256) % int(ecc_table['n'], 16)
    leaks=leak(start, bits, k)
    L.append(leaks)
    sigs.append(sm2.sign(msg, k))

key = hashlib.md5(str(sk).encode()).digest()
aes = AES.new(key, AES.MODE_ECB)
enc = aes.encrypt(flag)
print(sigs)
print(L)
print(enc)
'''
['1de6f33a8366acbdd0b87ec7beb59e429936b43bae9b8ee2538d2b97d6640c70143fa04e7f1880d22b0e9cbce938edd880d69fc4ed9a6315abd905880a8d38f7', '9d5f8a16fe8d951cbab0a6dca86427286ca389aca6497f20ca3421fa0aa27f4ddf2db6c58229182eaccca41bfebf56961ff1f683ba94b81137c41f61c98c1368', '4d20e1aa4e4f6a4948158fabbdadec3c4d6049b6439981efcb70900d954d0a8f18bce67831d426c12726c321e6eb69e8708739fc74bfde6ad601433bcd896ca7', 'e5358c986a12ec11bcd495e8822c5a71b2545dc11ce09521edaa47c11b739b12bbe76ca89bd08beb969355dec56dfcdd6cff121bb61eaea148d25e9a6e428145', 'fb06d41eafbcc77d464fe41ca356641cbb92289d28b0ff37caad95619c34557969acf9f615214f3ecf6c15943fc63470da0785687ae535045145d5e161a69210', '2e97f02e82642c033af0fc9686788c1acd8841b65228fab3e66f5328e790d702edadb13e99ed1d411482cd913ec6730803e6fcff29206d9e1fc1b68e1f631e25', '4f1ffd080380e945b24596135e5772058ee8adc26272ed3147f0701063b4b9f435e5ac679ef2cd950332ea5139d64ffee7f1211ea64c5beffa162bb942683fac', '0882c54ba0409f28ab3907831eedab320bf3645fd70888266393704f81998ed57778912ededb54c58efd6fc9f22188566824ae312d4585f87d37339fd87827e6', '9dafe7cee839389cbd5a72ac17befad3228b47192ed3a94a319eef67704c094adfeca2f14a1cea54540e7d69c6033c53fdbe60969cc910b31b1fce8c9d6a9d5b', '627357126622ad1b76354b4f6974120f670baf035e24599e36c9f14527f225e6acb0e00482c3ab7442858070181eb3a7fc4acd8de5e5411aa482b094c6e1a1fa', 'a9c7c29b800677ac44427204bc2137f0641465a411a521d3567911ab364c426c7a340ad1dcddb2330667bc78925bbec8bfd47cbf8031496e468f5ff3f9cc8a71', '23429d961d3bcf2e4873379afba581b351441c2d33c37c1fb5e84cdc22045a99bac91b3d8e3c90de3d56d443e439246872ab8fbd4ff42fbbd37509f79ccedd6e', '2847983b8f9492fe88c988d04b8086b94d8f827684e10cf2d4db1f5c65c1a7354c6e15df548df379ea5a56b57de9e36faf36c8d05270dc4bf69577ecbb5c1300', 'c684e4714cd002abea6fa5bd23014a152cf358ab848179fdc29f1b79b090b42c550ea43718e3e2c4bea2ece080db41fb9433539cac0b8ac8e419bcdbb6477017', '34e969156c0ff98ccff9dbe2757a365e24e81857937cc3056a1b837d67a5bc0215c99aa15ac8150c6cee089623000104017ac535ef3a7fd10bb46b008e64bf12', 'b79275b644dd73661b947fb786054b114fc90bcdf19cdd2a4cc96c426a3581d854619d95c3b9864534f9fe66445336e55c1a79527825706500527392ebac7ba6', 'f7302bd4f492be0537536a5327dab593b903346a5e32bf0262f494f11bb3968a736ae1a90abebe7ab600d899b001e8e4704117b862cf7787df29b1b8cda76227', 'e7d378b1f273baaaab041d3d81d669a351abe21d5987403fbb7d35f957a82ebcf0ffbbef77a08c1807d6e19d33053a62801f151bb81d0179bdb09fefd45a845d', '8c8dddfe7c2ee295c4aad0f207517cb00a5870c93c38af0e7438510f80b6788f7e863da10ec0650ab661ead1ae799dc63d3f7115c018a1d1961a068cff25ff21', '7382adaeab3aaed04178cf90bcb2750e11498f17dda2e058bbed931e9ff55faaa3fcc5af423ac139fd936fff916c78a5de316e67b5226d804e2590c65ad191c8', '70385b3c8fa2fd47be6963683256ebcbf2eb0a81f76856cb9524d59dcc1f910f98b0c37687857da008c6901fd78a9cf3b8b0ea9d744c8ab3b3d1b70277372572', '13f510e214b5bb7dbb81fadd772835f6fd0f082252ab775ab72c1b62b1573466a39d634f428202dd67bb4cdbb692a2a5dd148a49504d021d4aa5d903fac02cb1', '0910c842616b8b4c7f2ab265172e1d682a89b79f97019473d517b606dd43999e343ad4b08a71b69a1f4ffc8db39f7deb0a3c51c44652b1c63e090d901f43b33d', '7129bd6c31cc1e7f480fa713d9ba5386fdac580593229ca77baf96ea41e87fcd5b4c83693fc4b6b37959fc80391e05b279acad320fbd03e1c332e4cedc86a5b7', 'b6b80ce7dfe5a9fe066fce563a486c4a5f07611ab484131faf9381dc794a329390c60b53080d8360903f5759a18a1eca1b265655ef43ca213544c31e99fe0087', '7bfdca43b8d21d48e18dae387ea95c4ba690bff5fe22f3a29637c196a2288fdde98ec73554123dc33c8af567c7b98f9775600a0e34f32eae62655b47a0182171', 'b93eb6af65de700306b7a22816a1d461451c694de5ce55464be57cce89e8349f81a6d3fcc52da72c5d14df88bbe5ff683b591788d3edc91006a99ed1171ecce0', '1ab26e7f8a1e8854a73f2904d781f9f551d5b325fea4ec3f7ec45a03fc8d0b087b054f6475c21a473f5b47d6a980539b6a0aaf207bf89b3cc46eaf7fbf63411d', 'bea21a265e48c2624ba85137392dde1971325909fdfb97f57397f422cd6a152ef75c99b0634d6863aa4d7b4f07648d10c7ed3eeb210dc86691d0e2b463471ba8', 'e49e1b08e4865d8da0a278c049b2826a6b97911adbdaa836fd57f509f96db436327318bbf82c98b8d9f607e99c48db663473e4e941eb6109b174375a157eeb60', '72f00c548fc2539a8914b135b80a37e5137fa267579bcf11b566d4c44ee57defced7d0d3a2ec9923aa2790e80ac61a151b79e7b2dd17accbc7dd66c8e41d7489', 'c0d86918879d4ccfa4adf3fbd449c9b26a17b61073221a15d576e9528e0e29fcf3b164020043ac2a5752768ac996fa15e551c36dfd6c1dbf0d24d81d2e5b6724', 'ffd6eca8075af0c4fe4f38d4b3950ed76a4cc1474eadbd65b38484138456a98a4f4cc697c2d455d386e432679722f32cc59d1aa5135eb72cb10b5a82380b4e71', 'a3407cb209c1a6788ba1ca992a7b6cc04ef1130f92be63b9738dae873f3e407b440788115edd81ef3c2e791e10798c3fd1830ca5b4773523ef246cf13fbd5a5c', '3b1fe148835ebeece99b0df444cb2705e195d5d364fdbaf2fa754797c8f7484461327d471b258f9b0b5dcfb757a08d50b0ac334154fd6d4d0d68c2a846de4163', 'cc12da7bed20a53b5af9eebae5a94177f745ed5d48c4690cb462c498019e6a516b52cc9953620c04e12a79b45e99fc8164a79f00268c648801824a690a01b78f', 'e4e36894a7323e5fb1dc54366acd4fd3f6d9ec2817bd1c153d3d84ed544893d6f5c8a7fe839acf4880eb8df6c8ced3f2f7d947835a496da7b010bf6c5b04d669', 'a365dd19731e2d0ad844856da269d53a895ddcf5195b16f4e858ba4f83d99f2bbc49f7e7f61a431297545a3c9f3b99815a5a9645f83b1ac3acf1ca61481812fd', '0feb0860a5f6f2eaffc35e02a63633335b702e8bb1ef5c24dc82848cf3145149f4cede4352366db459784fa843ba0a20cec648b2674704bfe8facc2eb97a0fc5', '47c15d55e9a7f31ad5566213f8d0bdb6c4082b3dc2506f6d9d55af00fefe41a8c7ebe0255430efc5f6e7f5858fadd8478959afaf23ed57871ff78c676d0a1cd0', 'c15d5a156453862bd6d7d3634dbbc711fcbe38e04a71cec69ff936347417fe439343f93a0a0a0d51712ce44fa277861cee82c350341fe00c28448e3fc6956cfa', '42a93a785ff208608b4deeac184a7f882e75c9d45e5c1fec6c4cd08f5efe08c27d5a670676e4c8697ad0813b02fe50f19e7a0bf189716a2796b9804f737d5a98', '33e06326cc15e21e9a7d2f5b45facd397d9ef13315bb792356432fcb63e22ce15f1da0a8db378660ee1b8ce9286f772663f16da0cf6bbce149392d50e24096cc', '1c11c1cbd0b3e468b7671c2ad1030506542935716c27cd0e241bc68144390a615f50af737bc2da9a72872ebae750e962a225d0dff561d879f919d187f95e4878', 'd96905497145789b9734797625ede70eafcb8fc5eedbac4278091aba0d7c4b2bfe74e97ef5f966c1a3b408d91a36290a94027677c8b02d62e1a2b6498550c61a', 'ab5accec0103e2809ff5a59c8b3ac3d1426441981f8c6413003c4b69494f54d1cc7d6bf352373c2d60f8aa3b0b2236d2ae150b02bea2f5d353e9b3400519be8e', '341cd45d80593cf158aac070433333500633f6bca596ea07b758729f7f1c2c9391a9dfa56bfd6810b2e21b0009fc84e4a309805288ace599b80eabe35feaebc7', '944769dafb279eb7998d136427e894cba7fb2fbc7f13e4137eabfaaec26f0bdc0779c212756e5c0ac849d285a5b6900174d2042759eeb1d3f5b0e49c58176e2c', '2dfaea9976d6d33109c778e28acb0647a01a4abff01df29b35d51b2359cccc75bac8772de117a47c64821566087de13bd8ab16f72e189c7a934b19b56734fee0', 'c613ddab5dd81096088f185a1ead16ea0e6d99facd0249535b4327e11bd53fac5fd1b3807fef181a93cc048dbd4387e64c8281ead7bf2a28970739900633b7ad']
[87, 18, 88, 63, 30, 66, 60, 85, 13, 82, 35, 28, 21, 74, 47, 6, 30, 111, 97, 51, 42, 61, 92, 70, 113, 43, 7, 21, 68, 10, 99, 57, 87, 51, 43, 44, 60, 39, 117, 6, 88, 48, 47, 51, 56, 91, 6, 29, 92, 82]
b's\xda\xed\r\x8e/\xde\xa4\x99\x93\xcdCBB\x1c\xae\xcbB\x9f\xdd\xd4\x96\x9f\xa5O\xbf\x16\xa4\xecL\xe7J\x97\x1a\xdf\xa1\xa1\x92i,\xdd\x8a\xb6\xcfp}ho'
'''